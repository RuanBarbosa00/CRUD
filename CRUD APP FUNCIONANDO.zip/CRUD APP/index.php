
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Application</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <h1>CRUD Application</h1>
</header>

<div class="container">

<?php
include 'includes/header.php';
?>

<h2>Welcome to my Student Records Application</h2>

<?php
include 'includes/footer.php';
?>

</div>
</body>
</html>
